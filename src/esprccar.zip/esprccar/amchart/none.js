AmCharts.themes.none={};
